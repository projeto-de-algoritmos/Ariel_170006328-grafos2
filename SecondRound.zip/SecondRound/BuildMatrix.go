package main

import (
	"fmt"
	"os/exec"
)

func main() {

	runmaster := [25]string{
		"./imageprocessing/Images/builmidgard.sh",
		"./regions/buildmaster/build00.sh",
		"./regions/buildmaster/build01.sh",
		"./regions/buildmaster/build02.sh",
		"./regions/buildmaster/build03.sh",
		"./regions/buildmaster/build04.sh",
		"./regions/buildmaster/build05.sh",
		"./regions/buildmaster/build06.sh",
		"./regions/buildmaster/build07.sh",
		"./regions/buildmaster/build08.sh",
		"./regions/buildmaster/build09.sh",
		"./regions/buildmaster/build10.sh",
		"./regions/buildmaster/build11.sh",
		"./regions/buildmaster/build12.sh",
		"./regions/buildmaster/build13.sh",
		"./regions/buildmaster/build14.sh",
		"./regions/buildmaster/build15.sh",
		"./regions/buildmaster/build16.sh",
		"./regions/buildmaster/build17.sh",
		"./regions/buildmaster/build18.sh",
		"./regions/buildmaster/build19.sh",
		"./regions/buildmaster/build20.sh",
		"./regions/buildmaster/build21.sh",
		"./regions/buildmaster/build22.sh",
		"./regions/buildmaster/build23.sh"}

	jobs := make(chan int, 25)
	results := make(chan int, 25)

	go worker(jobs, results, runmaster)
	go worker(jobs, results, runmaster)
	go worker(jobs, results, runmaster)
	go worker(jobs, results, runmaster)

	for i := 0; i < 100; i++ {
		jobs <- i
	}
	close(jobs)

	for j := 0; j < 100; j++ {
		fmt.Println(<-results)
	}
}

func worker(jobs <-chan int, results chan<- int, runmaster [25]string) {
	for n := range jobs {
		results <- RunAll(n, runmaster)
	}
}
func RunAll(n int, runmaster [25]string) int {
	fmt.Println("inside it", n, " time")

	out, err := exec.Command(runmaster[n]).Output()
	if err != nil {
		fmt.Printf("I found some error to run the  ", runmaster[n], "%s", err)
	} else {
		fmt.Println("\nCommand ", runmaster[n], "Successfully Executed")
	}
	output := string(out[:])
	fmt.Println(output)
	return n
}
