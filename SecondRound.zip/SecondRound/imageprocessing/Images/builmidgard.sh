#!/bin/bash
# chmod +x buildmidgard.sh   para tornar run.sh executavel

./buildmatrix <./imageprocessing/Images/0.txt >./imageprocessing/Images/midgard.txt

