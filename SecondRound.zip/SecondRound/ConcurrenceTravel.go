package main

import (
    "fmt"
    "os/exec"
)

func main() {
    travelmaster := [24]string{
        "./regions/travelmaster/travel00.sh",
        "./regions/travelmaster/travel01.sh",
        "./regions/travelmaster/travel02.sh",
        "./regions/travelmaster/travel03.sh",
        "./regions/travelmaster/travel04.sh",
        "./regions/travelmaster/travel05.sh",
        "./regions/travelmaster/travel06.sh",
        "./regions/travelmaster/travel07.sh",
        "./regions/travelmaster/travel08.sh",
        "./regions/travelmaster/travel09.sh",
        "./regions/travelmaster/travel10.sh",
        "./regions/travelmaster/travel11.sh",
        "./regions/travelmaster/travel12.sh",
        "./regions/travelmaster/travel13.sh",
        "./regions/travelmaster/travel14.sh",
        "./regions/travelmaster/travel15.sh",
        "./regions/travelmaster/travel16.sh",
        "./regions/travelmaster/travel17.sh",
        "./regions/travelmaster/travel18.sh",
        "./regions/travelmaster/travel19.sh",
        "./regions/travelmaster/travel20.sh",
        "./regions/travelmaster/travel21.sh",
        "./regions/travelmaster/travel22.sh",
        "./regions/travelmaster/travel23.sh"}

    jobs := make(chan int, 24)
    results := make(chan int, 24)

    go worker(jobs, results, travelmaster)
    go worker(jobs, results, travelmaster)
    go worker(jobs, results, travelmaster)
    go worker(jobs, results, travelmaster)
    go worker(jobs, results, travelmaster)
    go worker(jobs, results, travelmaster)

    for i := 0; i < 100; i++ {
        jobs <- i
    }
    close(jobs)

    for j := 0; j < 100; j++ {
        fmt.Println(<-results)
    }
}

func worker(jobs <-chan int, results chan<- int, runmaster [24]string) {
    for n := range jobs {
        results <- RunAll(n, runmaster)
    }
}
func RunAll(n int, runmaster [24]string) int {
    fmt.Println("Running: ", n)

    out, err := exec.Command(runmaster[n]).Output()
    if err != nil {
        fmt.Printf("I found some error to run the Travel: %s", err)
    } else {
        fmt.Println("\nCommand ", runmaster[n], " Successfully Executed")
    }
    output := string(out[:])
    fmt.Println(output)
    return n
}
