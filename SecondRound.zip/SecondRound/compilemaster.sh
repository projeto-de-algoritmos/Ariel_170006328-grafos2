#!/bin/bash
# chmod +x compilemaster.sh   para tornar compilemaster.sh executavel
g++ Paths.cpp -o ./executable/path `pkg-config --cflags --libs opencv` -g
g++ BuildMatrix.cpp -o ./executable/buildmatrix `pkg-config --cflags --libs opencv` -g
g++ DivideandConquer.cpp -o ./executable/divide `pkg-config --cflags --libs opencv` -g
g++ Travel.cpp -o ./executable/travel
