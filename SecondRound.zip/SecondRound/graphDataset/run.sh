#!/bin/bash
# chmod +x run.sh   para tornar run.sh executavel
gcc genDataSet.c
# ./a.out nomeArquivoSaida.txt NumDeNos
./a.out dataset3.txt 3
./a.out dataset4.txt 4
./a.out dataset5.txt 5
./a.out dataset6.txt 6
./a.out dataset7.txt 7
./a.out dataset8.txt 8
./a.out dataset9.txt 9
./a.out dataset10.txt 10
./a.out dataset11.txt 11

