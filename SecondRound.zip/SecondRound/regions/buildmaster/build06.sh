#!/bin/bash
# chmod +x build06.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/6.txt >./regions/txt_images/region06.txt

