#!/bin/bash
# chmod +x build08.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/8.txt >./regions/txt_images/region08.txt

