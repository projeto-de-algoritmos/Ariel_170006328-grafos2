#!/bin/bash
# chmod +x build14.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/14.txt >./regions/txt_images/region14.txt

