#!/bin/bash
# chmod +x build15.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/15.txt >./regions/txt_images/region15.txt

