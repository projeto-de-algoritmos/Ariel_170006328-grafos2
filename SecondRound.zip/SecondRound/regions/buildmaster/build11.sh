#!/bin/bash
# chmod +x build11.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/11.txt >./regions/txt_images/region11.txt

