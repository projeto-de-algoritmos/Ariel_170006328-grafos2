#!/bin/bash
# chmod +x build16.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/16.txt >./regions/txt_images/region16.txt

