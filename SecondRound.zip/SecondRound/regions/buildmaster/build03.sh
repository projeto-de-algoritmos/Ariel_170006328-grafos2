#!/bin/bash
# chmod +x build03.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/3.txt >./regions/txt_images/region03txt

