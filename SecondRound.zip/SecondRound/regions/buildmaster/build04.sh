#!/bin/bash
# chmod +x build04.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/4.txt >./regions/txt_images/region04.txt

