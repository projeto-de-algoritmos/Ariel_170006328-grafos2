#!/bin/bash
# chmod +x build21.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/21.txt >./regions/txt_images/region21.txt

