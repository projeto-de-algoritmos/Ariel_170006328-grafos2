#!/bin/bash
# chmod +x build19.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/19.txt >./regions/txt_images/region19.txt

