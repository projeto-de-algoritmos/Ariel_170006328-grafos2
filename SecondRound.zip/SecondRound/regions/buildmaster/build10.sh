#!/bin/bash
# chmod +x build10.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/10.txt >./regions/txt_images/region10.txt

