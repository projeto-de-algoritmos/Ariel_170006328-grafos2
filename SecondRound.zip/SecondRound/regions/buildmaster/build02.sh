#!/bin/bash
# chmod +x build02.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/2.txt >./regions/txt_images/region02.txt

