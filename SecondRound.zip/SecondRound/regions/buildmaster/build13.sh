#!/bin/bash
# chmod +x build13.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/13.txt >./regions/txt_images/region13.txt

