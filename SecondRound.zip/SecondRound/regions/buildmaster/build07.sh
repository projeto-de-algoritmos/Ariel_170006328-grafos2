#!/bin/bash
# chmod +x build07.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/7.txt >./regions/txt_images/region07.txt

