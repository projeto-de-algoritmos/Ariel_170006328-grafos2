#!/bin/bash
# chmod +x build20.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/20.txt >./regions/txt_images/region20.txt

