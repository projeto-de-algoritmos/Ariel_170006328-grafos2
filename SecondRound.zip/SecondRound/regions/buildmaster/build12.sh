#!/bin/bash
# chmod +x build12.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/12.txt >./regions/txt_images/region12.txt

