#!/bin/bash
# chmod +x build23.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/23.txt >./regions/txt_images/region23.txt

