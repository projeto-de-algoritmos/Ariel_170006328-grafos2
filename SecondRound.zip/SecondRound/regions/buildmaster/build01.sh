#!/bin/bash
# chmod +x build01.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/1.txt >./regions/txt_images/region01.txt

