#!/bin/bash
# chmod +x build22.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/22.txt >./regions/txt_images/region22.txt

