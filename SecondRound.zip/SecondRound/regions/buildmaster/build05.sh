#!/bin/bash
# chmod +x build05.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/5.txt >./regions/txt_images/region05.txt

