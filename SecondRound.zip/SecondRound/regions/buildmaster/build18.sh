#!/bin/bash
# chmod +x build18.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/18.txt >./regions/txt_images/region18.txt

