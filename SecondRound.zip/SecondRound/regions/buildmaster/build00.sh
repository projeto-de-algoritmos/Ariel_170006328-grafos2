#!/bin/bash
# chmod +x build00.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/0.txt  >./regions/txt_images/region00.txt

