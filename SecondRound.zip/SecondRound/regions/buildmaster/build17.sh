#!/bin/bash
# chmod +x build17.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/17.txt >./regions/txt_images/region17.txt

