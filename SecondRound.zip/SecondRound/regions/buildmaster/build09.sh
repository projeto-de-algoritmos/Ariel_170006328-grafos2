#!/bin/bash
# chmod +x build09.sh   para tornar run.sh executavel

./executable/buildmatrix <./regions/N/9.txt >./regions/txt_images/region09.txt

