#!/bin/bash
# chmod +x run04.sh   para tornar run.sh executavel

./path <./regions/spots/spots04.txt >./regions/reggraphs/graph04.txt

