#!/bin/bash
# chmod +x run14.sh   para tornar run.sh executavel

./path <./regions/spots/spots13.txt >./regions/reggraphs/graph13.txt

