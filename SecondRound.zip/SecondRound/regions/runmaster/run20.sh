#!/bin/bash
# chmod +x run20.sh   para tornar run.sh executavel

./path <./regions/spots/spots20.txt >./regions/reggraphs/graph20.txt

