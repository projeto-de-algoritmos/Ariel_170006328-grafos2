#!/bin/bash
# chmod +x run12.sh   para tornar run.sh executavel

./path <./regions/spots/spots12.txt >./regions/reggraphs/graph12.txt

