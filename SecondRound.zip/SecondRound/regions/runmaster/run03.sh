#!/bin/bash
# chmod +x run03.sh   para tornar run.sh executavel

./path <./regions/spots/spots03.txt >./regions/reggraphs/graph03.txt

