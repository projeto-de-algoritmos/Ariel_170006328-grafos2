#!/bin/bash
# chmod +x run21.sh   para tornar run.sh executavel

./path <./regions/spots/spots21.txt >./regions/reggraphs/graph21.txt

