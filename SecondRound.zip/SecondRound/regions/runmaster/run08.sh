#!/bin/bash
# chmod +x run08.sh   para tornar run.sh executavel

./path <./regions/spots/spots08.txt >./regions/reggraphs/graph08.txt

