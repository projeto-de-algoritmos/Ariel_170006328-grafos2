#!/bin/bash
# chmod +x run19.sh   para tornar run.sh executavel

./path <./regions/spots/spots19.txt >./regions/reggraphs/graph19.txt

