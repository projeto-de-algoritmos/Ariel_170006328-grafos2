#!/bin/bash
# chmod +x run22.sh   para tornar run.sh executavel

./path <./regions/spots/spots22.txt >./regions/reggraphs/graph22.txt

