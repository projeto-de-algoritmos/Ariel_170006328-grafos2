#!/bin/bash
# chmod +x run01.sh   para tornar run.sh executavel

./path <./regions/spots/spots01.txt >./regions/reggraphs/graph01.txt

