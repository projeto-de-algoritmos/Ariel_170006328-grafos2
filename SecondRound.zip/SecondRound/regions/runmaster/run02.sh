#!/bin/bash
# chmod +x run02.sh   para tornar run.sh executavel

./path <./regions/spots/spots02.txt >./regions/reggraphs/graph02.txt

