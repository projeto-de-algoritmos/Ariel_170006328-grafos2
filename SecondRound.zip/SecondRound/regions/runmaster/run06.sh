#!/bin/bash
# chmod +x run06.sh   para tornar run.sh executavel

./path <./regions/spots/spots06.txt >./regions/reggraphs/graph06.txt

