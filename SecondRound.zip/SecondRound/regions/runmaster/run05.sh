#!/bin/bash
# chmod +x run05.sh   para tornar run.sh executavel

./path <./regions/spots/spots05.txt >./regions/reggraphs/graph05.txt

