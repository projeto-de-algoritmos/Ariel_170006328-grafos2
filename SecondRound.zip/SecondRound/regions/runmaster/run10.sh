#!/bin/bash
# chmod +x run10.sh   para tornar run.sh executavel

./path <./regions/spots/spots10.txt >./regions/reggraphs/graph10.txt

