#!/bin/bash
# chmod +x run07.sh   para tornar run.sh executavel

./path <./regions/spots/spots07.txt >./regions/reggraphs/graph07.txt

