#!/bin/bash
# chmod +x run18.sh   para tornar run.sh executavel

./path <./regions/spots/spots18.txt >./regions/reggraphs/graph18.txt

