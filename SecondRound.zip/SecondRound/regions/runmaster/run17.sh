#!/bin/bash
# chmod +x run17.sh   para tornar run.sh executavel

./path <./regions/spots/spots17.txt >./regions/reggraphs/graph17.txt

