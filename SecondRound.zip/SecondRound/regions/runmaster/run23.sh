#!/bin/bash
# chmod +x run23.sh   para tornar run.sh executavel

./path <./regions/spots/spots23.txt >./regions/reggraphs/graph23.txt

