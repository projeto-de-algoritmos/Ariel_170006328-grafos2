#!/bin/bash
# chmod +x run00.sh   para tornar run.sh executavel

./path <./regions/spots/spots00.txt >./regions/reggraphs/graph00.txt
