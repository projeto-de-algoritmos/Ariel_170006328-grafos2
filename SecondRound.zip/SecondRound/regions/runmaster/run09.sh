#!/bin/bash
# chmod +x run09.sh   para tornar run.sh executavel

./app <./regions/spots/spots09.txt >./regions/reggraphs/graph09.txt

