#!/bin/bash
# chmod +x run15.sh   para tornar run.sh executavel

./path <./regions/spots/spots15.txt >./regions/reggraphs/graph15.txt

