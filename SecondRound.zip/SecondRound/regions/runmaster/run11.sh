#!/bin/bash
# chmod +x run11.sh   para tornar run.sh executavel

./path <./regions/spots/spots11.txt >./regions/reggraphs/graph11.txt

