#!/bin/bash
# chmod +x run14.sh   para tornar run.sh executavel

./path <./regions/spots/spots14.txt >./regions/reggraphs/graph14.txt

