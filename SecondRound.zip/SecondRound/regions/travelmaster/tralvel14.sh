./travel <./regions/clusteres/cluster14.txt >./results/paths/path14.txt
