./travel <./regions/clusteres/cluster19.txt >./results/paths/path19.txt
