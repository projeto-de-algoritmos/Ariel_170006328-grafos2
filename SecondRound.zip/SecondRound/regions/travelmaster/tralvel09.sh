./travel <./regions/clusteres/cluster09.txt >./results/paths/path09.txt
