./travel <./regions/clusteres/cluster11.txt >./results/paths/path11.txt
