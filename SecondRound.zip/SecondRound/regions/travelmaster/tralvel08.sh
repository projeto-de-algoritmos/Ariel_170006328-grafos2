./travel <./regions/clusteres/cluster08.txt >./results/paths/path08.txt
