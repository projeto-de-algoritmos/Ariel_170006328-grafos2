./travel <./regions/clusteres/cluster15.txt >./results/paths/path15.txt
