./travel <./regions/clusteres/cluster20.txt >./results/paths/path20.txt
