./travel <./regions/clusteres/cluster13.txt >./results/paths/path13.txt
