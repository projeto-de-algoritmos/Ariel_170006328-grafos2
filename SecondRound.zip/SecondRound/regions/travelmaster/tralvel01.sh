./travel <./regions/clusteres/cluster01.txt >./results/paths/path01.txt
