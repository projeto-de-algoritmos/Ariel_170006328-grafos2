./travel <./regions/clusteres/cluster16.txt >./results/paths/path16.txt
