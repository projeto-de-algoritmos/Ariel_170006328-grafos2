./travel <./regions/clusteres/cluster21.txt >./results/paths/path21.txt
