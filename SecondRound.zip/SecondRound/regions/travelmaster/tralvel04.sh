./travel <./regions/clusteres/cluster04.txt >./results/paths/path04.txt
