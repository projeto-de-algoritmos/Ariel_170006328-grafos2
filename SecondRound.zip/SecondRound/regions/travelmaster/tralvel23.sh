./travel <./regions/clusteres/cluster23.txt >./results/paths/path23.txt
