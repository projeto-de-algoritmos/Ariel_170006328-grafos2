./travel <./regions/clusteres/cluster17.txt >./results/paths/path17.txt
