./travel <./regions/clusteres/cluster00.txt >./results/paths/path00.txt
