./travel <./regions/clusteres/cluster06.txt >./results/paths/path06.txt
