./travel <./regions/clusteres/cluster12.txt >./results/paths/path12.txt
