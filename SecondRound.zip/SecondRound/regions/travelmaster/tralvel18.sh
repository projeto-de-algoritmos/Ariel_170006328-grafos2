./travel <./regions/clusteres/cluster18.txt >./results/paths/path18.txt
