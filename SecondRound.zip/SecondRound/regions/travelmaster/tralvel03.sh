./travel <./regions/clusteres/cluster03.txt >./results/paths/path03.txt
