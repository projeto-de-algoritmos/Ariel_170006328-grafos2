./travel <./regions/clusteres/cluster05.txt >./results/paths/path05.txt
