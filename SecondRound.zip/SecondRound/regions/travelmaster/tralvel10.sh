./travel <./regions/clusteres/cluster10.txt >./results/paths/path10.txt
