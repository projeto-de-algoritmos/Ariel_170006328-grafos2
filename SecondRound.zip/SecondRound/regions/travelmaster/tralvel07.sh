./travel <./regions/clusteres/cluster07.txt >./results/paths/path07txt
