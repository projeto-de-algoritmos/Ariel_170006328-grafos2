./travel <./regions/clusteres/cluster02.txt >./results/paths/path02.txt
