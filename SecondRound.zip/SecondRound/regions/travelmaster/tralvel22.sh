./travel <./regions/clusteres/cluster22.txt >./results/paths/path22.txt
