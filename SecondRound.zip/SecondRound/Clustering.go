package main

import (
	"fmt"
	"math"
	"os"
	"strconv"
)

var Spots [192][2]int
var Clusters [24][192][2]int
var Init [24][2]int
var Centers [24][2]int
var next [24]int
var cluster int

func check(e error) {
	if e != nil {
		panic(e)
	}
}

func BuildClusteres(index int) int {
	var dists [24]float64
	var cluster = 0
	var current float64 = 9999999999
	var val float64
	for i := 0; i < 24; i++ {
		val = float64((Spots[index][0] - Centers[i][0]) * (Spots[index][0] - Centers[i][0]))
		val = val + float64((Spots[index][1]-Centers[i][1])*(Spots[index][1]-Centers[i][1]))
		dists[i] = math.Sqrt(val)
		if (dists[i] < current) && (next[i] <= 7) {
			cluster = i
			current = dists[i]
		}
	}
	return cluster
}

func main() {

	arg := os.Args[1:]

	var colstep = 540
	var rowstep = 640
	argint, err := strconv.Atoi(arg[0])

	for i := 0; i < 24; i++ {
		_, err := fmt.Scanf("%d %d", &Init[i][0], &Init[i][1]) //col and row

		if err != nil {
			fmt.Println(err)
		}

		Centers[i][0] = Init[i][0] + colstep
		Centers[i][1] = Init[i][1] + rowstep

		//fmt.Println(Centers[i][0], " ", Centers[i][1])

		next[i] = 0
	}
	for i := 0; i < 192; i++ {
		_, err := fmt.Scanf("%d %d", &Spots[i][0], &Spots[i][1]) //col and row

		if err != nil {
			fmt.Println(err)
		}

		//fmt.Println(Spots[i][0], " ", Spots[i][1])
	}

	for i := 0; i < 192; i++ {

		cluster = BuildClusteres(i)

		//fmt.Println(cluster)

		Clusters[cluster][next[cluster]][0] = Spots[i][0]
		Clusters[cluster][next[cluster]][1] = Spots[i][1]

		next[cluster]++
	}
	if err == nil {
		fmt.Println(argint)
		fmt.Println(1)
		fmt.Println(0)
		for s := 0; s < 8; s++ {
			fmt.Println(Clusters[argint][s][0], " ", Clusters[argint][s][1])
		}
	}

	// for i := 0; i < 24; i++ {
	// 	for o := 0; o < 8; o++ {
	// 		for d := 0; d < 8; d++ {
	// 			//dist = Findpath(o,d)
	// 		}
	// 	}
	// }
	// for i := 0; i < 24; i++ {
	// 	fmt.Println("Cluster ", i, " have", next[i], " nodes")
	// }
}
