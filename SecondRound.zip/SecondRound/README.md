# Procura de melhor caminho

Este projeto visa aprimorar o projeto anterior que  aplica o caixeiro viajante em imagens.
Como a solução perfeita sequencial é de ordem fatorial O(N!), uma implementação usando recursos concorrentes nativos de go e uma solução usando busca de menor aresta foram implementados, tendo em vista que essas são soluções aproximadas as duas são opções nesse projeto.
O objetivo desse projeto é implementar as 2 soluções.


## Autor

| Nomde | github |
|:-----:|:------:|
| Ariel Vieira Lima Serafim | [@ArielSixwings](https://github.com/ArielSixwings/) |


## Instalação e Execução


```shell
$ git clone https://github.com/ArielSixwings/Divide-and-conquer

//para baixar e instalar o gocv(consequentemente o opencv, que lhe permite trabalhar com c++) para o uso de go+opencv, execute:
$ masterframebuild.sh
```
obs: Para executar a aplicação é necessário a instalação do [go](https://golang.org/doc/install) e [gocv](https://gocv.io/getting-started/).

Para usar a solução 1 (busca de menor caminho usando menor aresta atual com alicação de poda) use:

#$ go run EdgeTravel.go <path.txt

Para usar a solução 2(caixeiro viajante em clusters) use:
(talvez seja necessário dar diversas permissões)

#$ ./compilemaster.sh
#$ ./master_run.sh

## Conceitos usados

-->Grafos em geral
-->Dijstra
-->Caixeiro viajante
-->Poda

