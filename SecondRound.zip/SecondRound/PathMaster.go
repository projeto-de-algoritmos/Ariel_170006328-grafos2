package main

import (
    "fmt"
    "os/exec"
)

func main() {
    var travelmaster = "pathmaster.sh"

    jobs := make(chan int, 1)
    results := make(chan int, 1)

    worker(jobs, results, travelmaster)

    jobs <- 1
    close(jobs)

    fmt.Println(<-results)

}

func worker(jobs <-chan int, results chan<- int, travelmaster string) {
    for n := range jobs {
        results <- RunAll(n, travelmaster)
    }
}
func RunAll(n int, travelmaster string) int {
    fmt.Println("Running: ", n)

    out, err := exec.Command(travelmaster).Output()
    if err != nil {
        fmt.Printf("I found some error to run the Travel: %s", err)
    } else {
        fmt.Println("\nCommand ", travelmaster, " Successfully Executed")
    }
    output := string(out[:])
    fmt.Println(output)
    return n
}
