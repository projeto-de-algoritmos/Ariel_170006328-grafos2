#!/bin/bash
# chmod +x run.sh   para tornar run.sh executavel

#go run BuildMatrix.go
#./executable/divide <init.txt
go build Clustering.go

echo "build clusteres"
./Clustering 0 <clusterinput.txt >./regions/clusteres/cluster00.txt
./Clustering 1 <clusterinput.txt >./regions/clusteres/cluster01.txt
./Clustering 2 <clusterinput.txt >./regions/clusteres/cluster02.txt
./Clustering 3 <clusterinput.txt >./regions/clusteres/cluster03.txt
./Clustering 4 <clusterinput.txt >./regions/clusteres/cluster04.txt
./Clustering 5 <clusterinput.txt >./regions/clusteres/cluster05.txt
./Clustering 6 <clusterinput.txt >./regions/clusteres/cluster06.txt
./Clustering 7 <clusterinput.txt >./regions/clusteres/cluster07.txt
./Clustering 8 <clusterinput.txt >./regions/clusteres/cluster08.txt
./Clustering 9 <clusterinput.txt >./regions/clusteres/cluster09.txt
./Clustering 10 <clusterinput.txt >./regions/clusteres/cluster10.txt
./Clustering 11 <clusterinput.txt >./regions/clusteres/cluster11.txt
./Clustering 12 <clusterinput.txt >./regions/clusteres/cluster12.txt
./Clustering 13 <clusterinput.txt >./regions/clusteres/cluster13.txt
./Clustering 14 <clusterinput.txt >./regions/clusteres/cluster14.txt
./Clustering 15 <clusterinput.txt >./regions/clusteres/cluster15.txt
./Clustering 16 <clusterinput.txt >./regions/clusteres/cluster16.txt
./Clustering 17 <clusterinput.txt >./regions/clusteres/cluster17.txt
./Clustering 18 <clusterinput.txt >./regions/clusteres/cluster18.txt
./Clustering 19 <clusterinput.txt >./regions/clusteres/cluster19.txt
./Clustering 20 <clusterinput.txt >./regions/clusteres/cluster20.txt
./Clustering 21 <clusterinput.txt >./regions/clusteres/cluster21.txt
./Clustering 22 <clusterinput.txt >./regions/clusteres/cluster22.txt
./Clustering 23 <clusterinput.txt >./regions/clusteres/cluster23.txt
echo "clusteres DONE!"

echo "runing cluster 0 in order to build graph00.txt"
./executable/path <./regions/clusteres/cluster00.txt >./regions/graphs/graph00.txt
echo "runing cluster 1 in order to build graph01.txt"
./executable/path <./regions/clusteres/cluster01.txt >./regions/graphs/graph01.txt
echo "runing cluster 2 in order to build graph02.txt"
./executable/path <./regions/clusteres/cluster02.txt >./regions/graphs/graph02.txt
echo "runing cluster 3 in order to build graph03.txt"
./executable/path <./regions/clusteres/cluster03.txt >./regions/graphs/graph03.txt
echo "runing cluster 4 in order to build graph04.txt"
./executable/path <./regions/clusteres/cluster04.txt >./regions/graphs/graph04.txt
echo "runing cluster 5 in order to build graph05.txt"
./executable/path <./regions/clusteres/cluster05.txt >./regions/graphs/graph05.txt
echo "runing cluster 6 in order to build graph06.txt"
./executable/path <./regions/clusteres/cluster06.txt >./regions/graphs/graph06.txt
echo "runing cluster 7 in order to build graph07.txt"
./executable/path <./regions/clusteres/cluster07.txt >./regions/graphs/graph07.txt
echo "runing cluster 8 in order to build graph08.txt"
./executable/path <./regions/clusteres/cluster08.txt >./regions/graphs/graph08.txt
echo "runing cluster 9 in order to build graph09.txt"
./executable/path <./regions/clusteres/cluster09.txt >./regions/graphs/graph09.txt
echo "runing cluster 10 in order to build graph10.txt"
./executable/path <./regions/clusteres/cluster10.txt >./regions/graphs/graph10.txt
echo "runing cluster 11 in order to build graph11.txt"
./executable/path <./regions/clusteres/cluster11.txt >./regions/graphs/graph11.txt
echo "runing cluster 12 in order to build graph12.txt"
./executable/path <./regions/clusteres/cluster12.txt >./regions/graphs/graph12.txt
echo "runing cluster 13 in order to build graph13.txt"
./executable/path <./regions/clusteres/cluster13.txt >./regions/graphs/graph13.txt
echo "runing cluster 14 in order to build graph14.txt"
./executable/path <./regions/clusteres/cluster14.txt >./regions/graphs/graph14.txt
echo "runing cluster 15 in order to build graph15.txt"
./executable/path <./regions/clusteres/cluster15.txt >./regions/graphs/graph15.txt
echo "runing cluster 16 in order to build graph16.txt"
./executable/path <./regions/clusteres/cluster16.txt >./regions/graphs/graph16.txt
echo "runing cluster 17 in order to build graph17.txt"
./executable/path <./regions/clusteres/cluster17.txt >./regions/graphs/graph17.txt
echo "runing cluster 18 in order to build graph18.txt"
./executable/path <./regions/clusteres/cluster18.txt >./regions/graphs/graph18.txt
echo "runing cluster 19 in order to build graph19.txt"
./executable/path <./regions/clusteres/cluster19.txt >./regions/graphs/graph19.txt
echo "runing cluster 20 in order to build graph20.txt"
./executable/path <./regions/clusteres/cluster20.txt >./regions/graphs/graph20.txt
echo "runing cluster 21 in order to build graph21.txt"
./executable/path <./regions/clusteres/cluster21.txt >./regions/graphs/graph21.txt
echo "runing cluster 22 in order to build graph22.txt"
./executable/path <./regions/clusteres/cluster22.txt >./regions/graphs/graph22.txt
echo "runing cluster 23 in order to build graph23.txt"
./executable/path <./regions/clusteres/cluster23.txt >./regions/graphs/graph23.txt


echo "Runing the Traveling Salesman with graph00.txt in order to build path00.txt"
./executable/travel <./regions/graphs/graph00.txt >./results/paths/path00.txt
echo "Runing the Traveling Salesman with graph01.txt in order to build path01.txt"
./executable/travel <./regions/graphs/graph01.txt >./results/paths/path01.txt
echo "Runing the Traveling Salesman with graph02.txt in order to build path02.txt"
./executable/travel <./regions/graphs/graph02.txt >./results/paths/path02.txt
echo "Runing the Traveling Salesman with graph03.txt in order to build path03.txt"
./executable/travel <./regions/graphs/graph03.txt >./results/paths/path03.txt
echo "Runing the Traveling Salesman with graph04.txt in order to build path04.txt"
./executable/travel <./regions/graphs/graph04.txt >./results/paths/path04.txt
echo "Runing the Traveling Salesman with graph05.txt in order to build path05.txt"
./executable/travel <./regions/graphs/graph05.txt >./results/paths/path05.txt
echo "Runing the Traveling Salesman with graph06.txt in order to build path06.txt"
./executable/travel <./regions/graphs/graph06.txt >./results/paths/path06.txt
echo "Runing the Traveling Salesman with graph07.txt in order to build path07.txt"
./executable/travel <./regions/graphs/graph07.txt >./results/paths/path07.txt
echo "Runing the Traveling Salesman with graph08.txt in order to build path08.txt"
./executable/travel <./regions/graphs/graph08.txt >./results/paths/path08.txt
echo "Runing the Traveling Salesman with graph09.txt in order to build path09.txt"
./executable/travel <./regions/graphs/graph09.txt >./results/paths/path09.txt
echo "Runing the Traveling Salesman with graph10.txt in order to build path10.txt"
./executable/travel <./regions/graphs/graph10.txt >./results/paths/path10.txt
echo "Runing the Traveling Salesman with graph11.txt in order to build path11.txt"
./executable/travel <./regions/graphs/graph11.txt >./results/paths/path11.txt
echo "Runing the Traveling Salesman with graph12.txt in order to build path12.txt"
./executable/travel <./regions/graphs/graph12.txt >./results/paths/path12.txt
echo "Runing the Traveling Salesman with graph13.txt in order to build path13.txt"
./executable/travel <./regions/graphs/graph13.txt >./results/paths/path13.txt
echo "Runing the Traveling Salesman with graph14.txt in order to build path14.txt"
./executable/travel <./regions/graphs/graph14.txt >./results/paths/path14.txt
echo "Runing the Traveling Salesman with graph15.txt in order to build path15.txt"
./executable/travel <./regions/graphs/graph15.txt >./results/paths/path15.txt
echo "Runing the Traveling Salesman with graph16.txt in order to build path16.txt"
./executable/travel <./regions/graphs/graph16.txt >./results/paths/path16.txt
echo "Runing the Traveling Salesman with graph17.txt in order to build path17.txt"
./executable/travel <./regions/graphs/graph17.txt >./results/paths/path17.txt
echo "Runing the Traveling Salesman with graph18.txt in order to build path18.txt"
./executable/travel <./regions/graphs/graph18.txt >./results/paths/path18.txt
echo "Runing the Traveling Salesman with graph19.txt in order to build path19.txt"
./executable/travel <./regions/graphs/graph19.txt >./results/paths/path19.txt
echo "Runing the Traveling Salesman with graph20.txt in order to build path20.txt"
./executable/travel <./regions/graphs/graph20.txt >./results/paths/path20.txt
echo "Runing the Traveling Salesman with graph21.txt in order to build path21.txt"
./executable/travel <./regions/graphs/graph21.txt >./results/paths/path21.txt
echo "Runing the Traveling Salesman with graph22.txt in order to build path22.txt"
./executable/travel <./regions/graphs/graph22.txt >./results/paths/path22.txt
echo "Runing the Traveling Salesman with graph23.txt in order to build path23.txt"
./executable/travel <./regions/graphs/graph23.txt >./results/paths/path23.txt
